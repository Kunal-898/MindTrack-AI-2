# MINDTRACK - Mental Health AI Application

A comprehensive mental health tracking application built with Streamlit, featuring AI-powered emotion analysis, mood tracking, and wellness analytics.

## Features

- **Login System**: Secure authentication to access your personal mental health dashboard
- **Daily Journaling**: Write about your thoughts and feelings with AI emotion analysis
- **Live Mood Tracker**: Circular gauge displaying current mood score and emotion breakdown
- **7-Day Wellness Trend**: Visual graph showing mood fluctuations over time
- **Analytics Dashboard**: Mood calendar heatmap and emotion frequency charts
- **Settings**: Customizable notifications, appearance, and data management

## Design

- Soft pastel colors (blues, mint greens, whites)
- Glassmorphism effects for modern UI
- Professional Inter typography
- Rounded corners and soft shadows
- Optimized for desktop viewing

## Installation

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the application:
```bash
streamlit run mindtrack_app.py
```

3. Open your browser and navigate to the URL shown in the terminal (typically `http://localhost:8501`)

## Usage

1. **Login**: Enter any username and password to access the dashboard
2. **Journal**: Write about your day in the journaling area and click "Analyze Emotion"
3. **View Analytics**: Click "Analytics" in the sidebar to see mood patterns and statistics
4. **Customize**: Use Settings to adjust preferences and manage your data

## Technologies

- **Streamlit**: Web application framework
- **Plotly**: Interactive visualizations and charts
- **Pandas**: Data manipulation and analysis
- **Python**: Core programming language

## Note

The emotion analysis uses a simple keyword-based algorithm for demonstration purposes. In a production environment, this would be replaced with a proper NLP/ML model or AI API.
