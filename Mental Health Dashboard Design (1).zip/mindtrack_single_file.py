"""
MINDTRACK - Mental Health AI Application
A comprehensive mental health tracking application built with Streamlit

Installation:
pip install streamlit pandas plotly

Run:
streamlit run mindtrack_single_file.py
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import random
from collections import Counter
import json

# Page configuration
st.set_page_config(
    page_title="MINDTRACK - Mental Health AI",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for styling
st.markdown("""
<style>
    /* Import Inter font */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

    /* Global styles */
    * {
        font-family: 'Inter', sans-serif;
    }

    /* Main background */
    .stApp {
        background: linear-gradient(135deg, #e0f2fe 0%, #ddd6fe 100%);
    }

    /* Card styling with glassmorphism */
    .glass-card {
        background: rgba(255, 255, 255, 0.7);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        padding: 25px;
        box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15);
        border: 1px solid rgba(255, 255, 255, 0.18);
        margin-bottom: 20px;
    }

    /* Button styling */
    .stButton>button {
        background: linear-gradient(135deg, #60a5fa 0%, #a78bfa 100%);
        color: white;
        border-radius: 12px;
        padding: 12px 24px;
        font-weight: 600;
        border: none;
        box-shadow: 0 4px 15px rgba(96, 165, 250, 0.3);
        transition: all 0.3s ease;
    }

    .stButton>button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(96, 165, 250, 0.4);
    }

    /* Text input styling */
    .stTextInput>div>div>input, .stTextArea>div>div>textarea {
        border-radius: 12px;
        border: 2px solid #e0f2fe;
        background: rgba(255, 255, 255, 0.8);
        padding: 12px;
    }

    /* Sidebar styling */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, rgba(224, 242, 254, 0.95) 0%, rgba(221, 214, 254, 0.95) 100%);
        backdrop-filter: blur(10px);
    }

    /* Metric styling */
    .stMetric {
        background: rgba(255, 255, 255, 0.6);
        padding: 15px;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    }

    /* Hide Streamlit branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}

    /* Headers */
    h1, h2, h3 {
        color: #1e293b;
        font-weight: 700;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'current_page' not in st.session_state:
    st.session_state.current_page = 'Home'
if 'journal_entries' not in st.session_state:
    st.session_state.journal_entries = []
if 'mood_history' not in st.session_state:
    # Generate sample mood data for the past 7 days
    st.session_state.mood_history = [
        {'date': (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d'),
         'mood_score': random.randint(60, 95),
         'emotions': random.sample(['Happy', 'Calm', 'Anxious', 'Sad', 'Excited', 'Stressed'], 2)}
        for i in range(6, -1, -1)
    ]

# Emotion analysis function (mock AI)
def analyze_emotion(text):
    """Analyze text and return emotion breakdown"""
    emotions = {
        'Happy': 0,
        'Sad': 0,
        'Anxious': 0,
        'Calm': 0,
        'Excited': 0,
        'Stressed': 0
    }

    # Simple keyword-based analysis (mock AI)
    text_lower = text.lower()

    happy_words = ['happy', 'joy', 'great', 'wonderful', 'excited', 'love', 'amazing']
    sad_words = ['sad', 'down', 'unhappy', 'depressed', 'crying', 'tears']
    anxious_words = ['anxious', 'worry', 'nervous', 'scared', 'fear', 'panic']
    calm_words = ['calm', 'peace', 'relaxed', 'tranquil', 'serene']
    excited_words = ['excited', 'thrilled', 'energized', 'pumped']
    stressed_words = ['stress', 'overwhelmed', 'pressure', 'busy', 'exhausted']

    for word in happy_words:
        if word in text_lower:
            emotions['Happy'] += 15
    for word in sad_words:
        if word in text_lower:
            emotions['Sad'] += 15
    for word in anxious_words:
        if word in text_lower:
            emotions['Anxious'] += 15
    for word in calm_words:
        if word in text_lower:
            emotions['Calm'] += 15
    for word in excited_words:
        if word in text_lower:
            emotions['Excited'] += 15
    for word in stressed_words:
        if word in text_lower:
            emotions['Stressed'] += 15

    # Add some random baseline values
    for emotion in emotions:
        emotions[emotion] += random.randint(5, 20)

    # Normalize to 100
    total = sum(emotions.values())
    if total > 0:
        emotions = {k: round((v / total) * 100) for k, v in emotions.items()}

    # Calculate overall mood score
    mood_score = emotions['Happy'] + emotions['Calm'] + emotions['Excited'] - emotions['Sad'] - emotions['Anxious'] - emotions['Stressed']
    mood_score = max(0, min(100, mood_score + 50))  # Normalize to 0-100

    return emotions, mood_score

# Login page
def login_page():
    st.markdown("<h1 style='text-align: center; margin-top: 100px; font-size: 3.5rem;'>🧠 MINDTRACK</h1>", unsafe_allow_html=True)
    st.markdown("<p style='text-align: center; font-size: 1.2rem; color: #64748b; margin-bottom: 50px;'>Your AI-Powered Mental Health Companion</p>", unsafe_allow_html=True)

    col1, col2, col3 = st.columns([1, 2, 1])

    with col2:
        st.markdown("<div class='glass-card'>", unsafe_allow_html=True)

        username = st.text_input("Username", placeholder="Enter your username")
        password = st.text_input("Password", type="password", placeholder="Enter your password")

        col_a, col_b, col_c = st.columns([1, 2, 1])
        with col_b:
            if st.button("Login", use_container_width=True):
                if username and password:
                    st.session_state.logged_in = True
                    st.session_state.username = username
                    st.rerun()
                else:
                    st.error("Please enter both username and password")

        st.markdown("</div>", unsafe_allow_html=True)
        st.markdown("<p style='text-align: center; margin-top: 20px; color: #64748b;'>Don't have an account? <a href='#' style='color: #60a5fa;'>Sign up</a></p>", unsafe_allow_html=True)

# Create circular gauge for mood score
def create_mood_gauge(score):
    fig = go.Figure(go.Indicator(
        mode = "gauge+number",
        value = score,
        domain = {'x': [0, 1], 'y': [0, 1]},
        gauge = {
            'axis': {'range': [None, 100], 'tickwidth': 1, 'tickcolor': "#60a5fa"},
            'bar': {'color': "#60a5fa"},
            'bgcolor': "white",
            'borderwidth': 2,
            'bordercolor': "#e0f2fe",
            'steps': [
                {'range': [0, 33], 'color': '#fecaca'},
                {'range': [33, 66], 'color': '#fde68a'},
                {'range': [66, 100], 'color': '#a7f3d0'}
            ],
            'threshold': {
                'line': {'color': "#a78bfa", 'width': 4},
                'thickness': 0.75,
                'value': score
            }
        }
    ))

    fig.update_layout(
        height=250,
        margin=dict(l=20, r=20, t=40, b=20),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font={'color': "#1e293b", 'family': "Inter"}
    )

    return fig

# Home/Dashboard page
def home_page():
    st.title("📊 Dashboard")

    # Main layout: left content, right sidebar
    col_main, col_right = st.columns([2, 1])

    with col_main:
        # Journaling section
        st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
        st.subheader("📝 Daily Journal")

        journal_text = st.text_area(
            "How are you feeling today?",
            placeholder="Write about your thoughts, feelings, and experiences...",
            height=200
        )

        if st.button("Analyze Emotion", type="primary"):
            if journal_text:
                emotions, mood_score = analyze_emotion(journal_text)

                # Save entry
                entry = {
                    'date': datetime.now().strftime('%Y-%m-%d %H:%M'),
                    'text': journal_text,
                    'emotions': emotions,
                    'mood_score': mood_score
                }
                st.session_state.journal_entries.insert(0, entry)

                # Update mood history
                today = datetime.now().strftime('%Y-%m-%d')
                existing = [m for m in st.session_state.mood_history if m['date'] == today]
                if existing:
                    existing[0]['mood_score'] = mood_score
                    existing[0]['emotions'] = [k for k, v in emotions.items() if v > 20]
                else:
                    st.session_state.mood_history.append({
                        'date': today,
                        'mood_score': mood_score,
                        'emotions': [k for k, v in emotions.items() if v > 20]
                    })

                st.success("✨ Emotion analyzed successfully!")
                st.rerun()
            else:
                st.warning("Please write something in your journal first")

        st.markdown("</div>", unsafe_allow_html=True)

        # Recent entries
        if st.session_state.journal_entries:
            st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
            st.subheader("📚 Recent Entries")

            for entry in st.session_state.journal_entries[:3]:
                with st.expander(f"Entry from {entry['date']} - Mood: {entry['mood_score']}/100"):
                    st.write(entry['text'])
                    st.write("**Emotion Breakdown:**")
                    cols = st.columns(3)
                    for idx, (emotion, value) in enumerate(entry['emotions'].items()):
                        with cols[idx % 3]:
                            st.metric(emotion, f"{value}%")

            st.markdown("</div>", unsafe_allow_html=True)

    with col_right:
        # Current mood tracker
        st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
        st.subheader("🎯 Current Mood")

        if st.session_state.journal_entries:
            latest_entry = st.session_state.journal_entries[0]
            mood_score = latest_entry['mood_score']
            emotions = latest_entry['emotions']
        else:
            mood_score = 75
            emotions = {'Happy': 30, 'Calm': 40, 'Anxious': 10, 'Sad': 5, 'Excited': 10, 'Stressed': 5}

        # Mood gauge
        fig_gauge = create_mood_gauge(mood_score)
        st.plotly_chart(fig_gauge, use_container_width=True)

        # Emotion breakdown
        st.markdown("**Emotion Breakdown**")
        for emotion, value in sorted(emotions.items(), key=lambda x: x[1], reverse=True)[:4]:
            st.progress(value / 100, text=f"{emotion}: {value}%")

        st.markdown("</div>", unsafe_allow_html=True)

    # Wellness trend graph (bottom)
    st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
    st.subheader("📈 7-Day Wellness Trend")

    df_mood = pd.DataFrame(st.session_state.mood_history)

    fig_trend = go.Figure()
    fig_trend.add_trace(go.Scatter(
        x=df_mood['date'],
        y=df_mood['mood_score'],
        mode='lines+markers',
        name='Mood Score',
        line=dict(color='#60a5fa', width=3, shape='spline'),
        marker=dict(size=10, color='#a78bfa', line=dict(color='white', width=2)),
        fill='tozeroy',
        fillcolor='rgba(96, 165, 250, 0.1)'
    ))

    fig_trend.update_layout(
        height=300,
        margin=dict(l=20, r=20, t=20, b=20),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(255,255,255,0.5)',
        xaxis=dict(title='Date', gridcolor='#e0f2fe'),
        yaxis=dict(title='Mood Score', gridcolor='#e0f2fe', range=[0, 100]),
        font={'color': "#1e293b", 'family': "Inter"},
        hovermode='x unified'
    )

    st.plotly_chart(fig_trend, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

# Analytics page
def analytics_page():
    st.title("📊 Analytics")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
        st.subheader("📅 Mood Calendar")

        # Create mood calendar heatmap
        df_mood = pd.DataFrame(st.session_state.mood_history)
        df_mood['date'] = pd.to_datetime(df_mood['date'])

        fig_calendar = px.density_heatmap(
            df_mood,
            x=df_mood['date'].dt.day_name(),
            y=df_mood['date'].dt.week,
            z='mood_score',
            color_continuous_scale='RdYlGn',
            labels={'mood_score': 'Mood Score'}
        )

        fig_calendar.update_layout(
            height=300,
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(255,255,255,0.5)',
            font={'color': "#1e293b", 'family': "Inter"}
        )

        st.plotly_chart(fig_calendar, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

    with col2:
        st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
        st.subheader("☁️ Emotion Word Cloud")

        # Collect all emotions
        all_emotions = []
        for entry in st.session_state.journal_entries:
            all_emotions.extend([k for k, v in entry['emotions'].items() if v > 15])

        if all_emotions:
            emotion_counts = Counter(all_emotions)

            fig_emotions = go.Figure(data=[go.Bar(
                x=list(emotion_counts.keys()),
                y=list(emotion_counts.values()),
                marker=dict(
                    color=list(emotion_counts.values()),
                    colorscale='Viridis',
                    showscale=True
                )
            )])

            fig_emotions.update_layout(
                height=300,
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(255,255,255,0.5)',
                font={'color': "#1e293b", 'family': "Inter"},
                xaxis=dict(title='Emotion'),
                yaxis=dict(title='Frequency')
            )

            st.plotly_chart(fig_emotions, use_container_width=True)
        else:
            st.info("Start journaling to see your emotion patterns!")

        st.markdown("</div>", unsafe_allow_html=True)

    # Statistics
    st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
    st.subheader("📈 Statistics")

    col_a, col_b, col_c, col_d = st.columns(4)

    with col_a:
        st.metric("Total Entries", len(st.session_state.journal_entries))

    with col_b:
        avg_mood = sum([m['mood_score'] for m in st.session_state.mood_history]) / len(st.session_state.mood_history)
        st.metric("Average Mood", f"{avg_mood:.1f}/100")

    with col_c:
        if st.session_state.mood_history:
            best_day = max(st.session_state.mood_history, key=lambda x: x['mood_score'])
            st.metric("Best Day", best_day['date'])

    with col_d:
        streak = min(len(st.session_state.journal_entries), 7)
        st.metric("Current Streak", f"{streak} days")

    st.markdown("</div>", unsafe_allow_html=True)

# Settings page
def settings_page():
    st.title("⚙️ Settings")

    st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
    st.subheader("👤 Profile Settings")

    username = st.text_input("Username", value=st.session_state.get('username', 'User'))
    email = st.text_input("Email", value="user@mindtrack.com")

    if st.button("Save Profile"):
        st.success("Profile updated successfully!")

    st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
    st.subheader("🔔 Notifications")

    daily_reminder = st.checkbox("Daily journal reminder", value=True)
    mood_alerts = st.checkbox("Mood pattern alerts", value=True)
    weekly_summary = st.checkbox("Weekly summary report", value=False)

    st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
    st.subheader("🎨 Appearance")

    theme = st.selectbox("Theme", ["Light (Pastel)", "Dark", "Auto"])
    font_size = st.slider("Font Size", 12, 20, 16)

    st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
    st.subheader("💾 Data Management")

    col1, col2 = st.columns(2)

    with col1:
        if st.button("Export Data", use_container_width=True):
            data = {
                'entries': st.session_state.journal_entries,
                'mood_history': st.session_state.mood_history
            }
            st.download_button(
                "Download JSON",
                json.dumps(data, indent=2),
                "mindtrack_data.json",
                "application/json"
            )

    with col2:
        if st.button("Clear All Data", use_container_width=True):
            if st.checkbox("I understand this action cannot be undone"):
                st.session_state.journal_entries = []
                st.success("Data cleared successfully!")

    st.markdown("</div>", unsafe_allow_html=True)

# Main app logic
def main():
    if not st.session_state.logged_in:
        login_page()
    else:
        # Sidebar navigation
        with st.sidebar:
            st.markdown("<h2 style='text-align: center; color: #60a5fa;'>🧠 MINDTRACK</h2>", unsafe_allow_html=True)
            st.markdown(f"<p style='text-align: center; color: #64748b;'>Welcome, {st.session_state.get('username', 'User')}!</p>", unsafe_allow_html=True)
            st.markdown("---")

            if st.button("🏠 Home", use_container_width=True):
                st.session_state.current_page = 'Home'

            if st.button("📝 Journal", use_container_width=True):
                st.session_state.current_page = 'Home'

            if st.button("📊 Analytics", use_container_width=True):
                st.session_state.current_page = 'Analytics'

            if st.button("⚙️ Settings", use_container_width=True):
                st.session_state.current_page = 'Settings'

            st.markdown("---")

            if st.button("🚪 Logout", use_container_width=True):
                st.session_state.logged_in = False
                st.session_state.current_page = 'Home'
                st.rerun()

        # Display current page
        if st.session_state.current_page == 'Home':
            home_page()
        elif st.session_state.current_page == 'Analytics':
            analytics_page()
        elif st.session_state.current_page == 'Settings':
            settings_page()

if __name__ == "__main__":
    main()
