import { X, Sparkles, TrendingUp } from "lucide-react";
import { Progress } from "./ui/progress";
import { motion, AnimatePresence } from "motion/react";

interface EmotionResult {
  emotion: string;
  percentage: number;
  color: string;
}

interface EmotionCardProps {
  isOpen: boolean;
  onClose: () => void;
  emotions: EmotionResult[];
  suggestions: string[];
}

export default function EmotionCard({ isOpen, onClose, emotions, suggestions }: EmotionCardProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40"
            onClick={onClose}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full max-w-lg z-50 p-4"
          >
            <div className="bg-white/90 backdrop-blur-2xl rounded-3xl shadow-2xl border border-white/50 p-8 relative">
              {/* Close Button */}
              <button
                onClick={onClose}
                className="absolute top-6 right-6 p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>

              {/* Header */}
              <div className="flex items-center gap-3 mb-6">
                <div className="p-3 bg-gradient-to-br from-blue-400 to-green-400 rounded-2xl">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl text-gray-800">AI Emotion Analysis</h3>
                  <p className="text-sm text-gray-500">Based on your journal entry</p>
                </div>
              </div>

              {/* Emotion Results */}
              <div className="space-y-4 mb-6">
                <h4 className="text-sm text-gray-700">Detected Emotions</h4>
                {emotions.map((emotion, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700">{emotion.emotion}</span>
                      <span className="text-sm font-semibold" style={{ color: emotion.color }}>
                        {emotion.percentage}%
                      </span>
                    </div>
                    <div className="relative">
                      <Progress value={emotion.percentage} className="h-3" />
                      <div
                        className="absolute inset-0 h-3 rounded-full opacity-20"
                        style={{
                          background: `linear-gradient(to right, ${emotion.color}, ${emotion.color})`,
                          width: `${emotion.percentage}%`,
                        }}
                      />
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* AI Suggestions */}
              <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  <h4 className="text-sm text-gray-800">AI Suggestions</h4>
                </div>
                <ul className="space-y-2">
                  {suggestions.map((suggestion, index) => (
                    <motion.li
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 + index * 0.1 }}
                      className="text-sm text-gray-700 flex items-start gap-2"
                    >
                      <span className="text-green-500 mt-0.5">•</span>
                      <span>{suggestion}</span>
                    </motion.li>
                  ))}
                </ul>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 mt-6">
                <button className="flex-1 bg-gradient-to-r from-blue-500 to-green-500 text-white py-3 rounded-xl hover:shadow-lg transition-all">
                  Save to Analytics
                </button>
                <button
                  onClick={onClose}
                  className="px-6 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
