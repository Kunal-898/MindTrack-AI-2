import { Smile, Frown, Meh, Heart, Zap } from "lucide-react";
import { Progress } from "./ui/progress";

interface MoodData {
  emotion: string;
  percentage: number;
  color: string;
  icon: React.ReactNode;
}

export default function MoodTracker() {
  const moodData: MoodData[] = [
    {
      emotion: "Joy",
      percentage: 65,
      color: "bg-blue-400",
      icon: <Smile className="w-5 h-5 text-blue-400" />,
    },
    {
      emotion: "Calm",
      percentage: 45,
      color: "bg-green-400",
      icon: <Heart className="w-5 h-5 text-green-400" />,
    },
    {
      emotion: "Neutral",
      percentage: 30,
      color: "bg-yellow-400",
      icon: <Meh className="w-5 h-5 text-yellow-400" />,
    },
    {
      emotion: "Stress",
      percentage: 20,
      color: "bg-orange-400",
      icon: <Zap className="w-5 h-5 text-orange-400" />,
    },
    {
      emotion: "Anxiety",
      percentage: 15,
      color: "bg-red-400",
      icon: <Frown className="w-5 h-5 text-red-400" />,
    },
  ];

  return (
    <div className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-lg border border-white/50 p-6">
      <h3 className="text-lg mb-6 text-gray-800">Live Mood Tracker</h3>

      {/* Circular Gauge - Main Mood */}
      <div className="flex flex-col items-center mb-8">
        <div className="relative w-40 h-40 mb-4">
          {/* Circular progress */}
          <svg className="transform -rotate-90 w-40 h-40">
            <circle
              cx="80"
              cy="80"
              r="70"
              stroke="#E0E7FF"
              strokeWidth="12"
              fill="none"
            />
            <circle
              cx="80"
              cy="80"
              r="70"
              stroke="url(#gradient)"
              strokeWidth="12"
              fill="none"
              strokeDasharray={`${2 * Math.PI * 70}`}
              strokeDashoffset={`${2 * Math.PI * 70 * (1 - 0.65)}`}
              strokeLinecap="round"
              className="transition-all duration-1000"
            />
            <defs>
              <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#60A5FA" />
                <stop offset="100%" stopColor="#34D399" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <Smile className="w-8 h-8 text-blue-500 mb-1" />
            <span className="text-2xl font-semibold text-gray-800">65%</span>
            <span className="text-xs text-gray-500">Joy</span>
          </div>
        </div>
        <p className="text-sm text-gray-600 text-center">
          Your dominant mood today
        </p>
      </div>

      {/* Emotion Breakdown */}
      <div className="space-y-4">
        <h4 className="text-sm text-gray-700 mb-3">Emotion Breakdown</h4>
        {moodData.map((mood, index) => (
          <div key={index} className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {mood.icon}
                <span className="text-sm text-gray-700">{mood.emotion}</span>
              </div>
              <span className="text-sm text-gray-600">{mood.percentage}%</span>
            </div>
            <Progress value={mood.percentage} className="h-2" />
          </div>
        ))}
      </div>

      {/* Today's Summary */}
      <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-green-50 rounded-2xl">
        <p className="text-xs text-gray-600 mb-1">Today's Summary</p>
        <p className="text-sm text-gray-800">
          You're feeling mostly positive! Keep up the good vibes. 🌟
        </p>
      </div>
    </div>
  );
}
