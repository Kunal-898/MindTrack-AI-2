import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts";

const data = [
  { day: "Mon", mood: 65, stress: 25 },
  { day: "Tue", mood: 72, stress: 30 },
  { day: "Wed", mood: 58, stress: 42 },
  { day: "Thu", mood: 68, stress: 28 },
  { day: "Fri", mood: 80, stress: 20 },
  { day: "Sat", mood: 85, stress: 15 },
  { day: "Sun", mood: 75, stress: 22 },
];

export default function WellnessTrend() {
  return (
    <div className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-lg border border-white/50 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg text-gray-800">Wellness Trend</h3>
          <p className="text-sm text-gray-500">Last 7 days</p>
        </div>
        <div className="flex gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-blue-400 rounded-full"></div>
            <span className="text-gray-600">Mood</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-orange-400 rounded-full"></div>
            <span className="text-gray-600">Stress</span>
          </div>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={280}>
        <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="colorMood" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#60A5FA" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#60A5FA" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="colorStress" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#FB923C" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#FB923C" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
          <XAxis
            dataKey="day"
            stroke="#9CA3AF"
            style={{ fontSize: "12px" }}
          />
          <YAxis stroke="#9CA3AF" style={{ fontSize: "12px" }} />
          <Tooltip
            contentStyle={{
              backgroundColor: "rgba(255, 255, 255, 0.95)",
              border: "none",
              borderRadius: "12px",
              boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
            }}
          />
          <Area
            type="monotone"
            dataKey="mood"
            stroke="#60A5FA"
            strokeWidth={3}
            fillOpacity={1}
            fill="url(#colorMood)"
          />
          <Area
            type="monotone"
            dataKey="stress"
            stroke="#FB923C"
            strokeWidth={3}
            fillOpacity={1}
            fill="url(#colorStress)"
          />
        </AreaChart>
      </ResponsiveContainer>

      <div className="grid grid-cols-3 gap-4 mt-6">
        <div className="text-center p-3 bg-blue-50 rounded-xl">
          <p className="text-xs text-gray-600 mb-1">Avg Mood</p>
          <p className="text-xl font-semibold text-blue-600">72%</p>
        </div>
        <div className="text-center p-3 bg-orange-50 rounded-xl">
          <p className="text-xs text-gray-600 mb-1">Avg Stress</p>
          <p className="text-xl font-semibold text-orange-600">26%</p>
        </div>
        <div className="text-center p-3 bg-green-50 rounded-xl">
          <p className="text-xs text-gray-600 mb-1">Trend</p>
          <p className="text-xl font-semibold text-green-600">↗ +8%</p>
        </div>
      </div>
    </div>
  );
}
