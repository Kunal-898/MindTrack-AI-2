import { useState } from "react";
import { useNavigate } from "react-router";
import { Home, BookOpen, BarChart3, Settings, Brain, LogOut, Calendar, TrendingUp, Cloud } from "lucide-react";
import { motion } from "motion/react";

export default function Analytics() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("analytics");

  // Mock mood calendar data (30 days)
  const moodCalendar = Array.from({ length: 30 }, (_, i) => ({
    day: i + 1,
    mood: Math.random() > 0.3 ? "good" : Math.random() > 0.5 ? "neutral" : "bad",
  }));

  // Mock word cloud data
  const wordCloudData = [
    { word: "grateful", size: 32, color: "#34D399" },
    { word: "work", size: 28, color: "#60A5FA" },
    { word: "happy", size: 30, color: "#FBBF24" },
    { word: "stressed", size: 20, color: "#F87171" },
    { word: "family", size: 26, color: "#A78BFA" },
    { word: "exercise", size: 22, color: "#10B981" },
    { word: "tired", size: 18, color: "#FB923C" },
    { word: "productive", size: 24, color: "#3B82F6" },
    { word: "anxious", size: 16, color: "#EF4444" },
    { word: "peaceful", size: 28, color: "#14B8A6" },
    { word: "friends", size: 20, color: "#8B5CF6" },
    { word: "sleep", size: 19, color: "#6366F1" },
  ];

  const navigationItems = [
    { id: "home", icon: Home, label: "Home" },
    { id: "journal", icon: BookOpen, label: "Journal" },
    { id: "analytics", icon: BarChart3, label: "Analytics" },
    { id: "settings", icon: Settings, label: "Settings" },
  ];

  const handleNavigation = (id: string) => {
    setActiveTab(id);
    if (id === "home" || id === "journal") {
      navigate("/dashboard");
    } else if (id === "settings") {
      navigate("/settings");
    }
  };

  const getMoodColor = (mood: string) => {
    switch (mood) {
      case "good":
        return "bg-green-400";
      case "neutral":
        return "bg-yellow-400";
      case "bad":
        return "bg-red-400";
      default:
        return "bg-gray-200";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      <div className="flex h-screen">
        {/* Left Sidebar */}
        <div className="w-20 bg-white/60 backdrop-blur-xl border-r border-white/50 flex flex-col items-center py-8 shadow-lg">
          {/* Logo */}
          <div className="mb-12">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-green-500 rounded-2xl flex items-center justify-center shadow-lg">
              <Brain className="w-7 h-7 text-white" />
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 flex flex-col gap-6">
            {navigationItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavigation(item.id)}
                className={`p-4 rounded-2xl transition-all duration-300 group relative ${
                  activeTab === item.id
                    ? "bg-gradient-to-br from-blue-500 to-green-500 shadow-lg"
                    : "hover:bg-white/50"
                }`}
              >
                <item.icon
                  className={`w-6 h-6 ${
                    activeTab === item.id ? "text-white" : "text-gray-600 group-hover:text-gray-800"
                  }`}
                />
                <span className="absolute left-20 bg-gray-800 text-white text-xs px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                  {item.label}
                </span>
              </button>
            ))}
          </nav>

          {/* Logout */}
          <button
            onClick={() => navigate("/")}
            className="p-4 rounded-2xl hover:bg-red-50 transition-all group"
          >
            <LogOut className="w-6 h-6 text-gray-600 group-hover:text-red-500" />
          </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8 overflow-y-auto">
          {/* Header */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <h1 className="text-3xl text-gray-800 mb-2">Analytics Dashboard</h1>
            <p className="text-gray-600">Insights into your mental wellness journey</p>
          </motion.div>

          {/* Stats Cards */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="grid grid-cols-4 gap-6 mb-8"
          >
            <div className="bg-white/70 backdrop-blur-xl rounded-2xl shadow-lg border border-white/50 p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm text-gray-600">Total Entries</h3>
                <BookOpen className="w-5 h-5 text-blue-500" />
              </div>
              <p className="text-3xl font-semibold text-gray-800">127</p>
              <p className="text-xs text-green-600 mt-2">+12 this month</p>
            </div>

            <div className="bg-white/70 backdrop-blur-xl rounded-2xl shadow-lg border border-white/50 p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm text-gray-600">Avg Mood</h3>
                <TrendingUp className="w-5 h-5 text-green-500" />
              </div>
              <p className="text-3xl font-semibold text-gray-800">72%</p>
              <p className="text-xs text-green-600 mt-2">↗ +8% from last week</p>
            </div>

            <div className="bg-white/70 backdrop-blur-xl rounded-2xl shadow-lg border border-white/50 p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm text-gray-600">Streak</h3>
                <Calendar className="w-5 h-5 text-orange-500" />
              </div>
              <p className="text-3xl font-semibold text-gray-800">14</p>
              <p className="text-xs text-gray-600 mt-2">days in a row</p>
            </div>

            <div className="bg-white/70 backdrop-blur-xl rounded-2xl shadow-lg border border-white/50 p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm text-gray-600">Top Emotion</h3>
                <Cloud className="w-5 h-5 text-purple-500" />
              </div>
              <p className="text-3xl font-semibold text-gray-800">Joy</p>
              <p className="text-xs text-gray-600 mt-2">Most frequent</p>
            </div>
          </motion.div>

          <div className="grid grid-cols-2 gap-8">
            {/* Mood Calendar */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-lg border border-white/50 p-8"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl text-gray-800">Mood Calendar</h2>
                  <p className="text-sm text-gray-500">Last 30 days</p>
                </div>
                <Calendar className="w-6 h-6 text-gray-600" />
              </div>

              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-3">
                {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                  <div key={day} className="text-center text-xs text-gray-500 mb-2">
                    {day}
                  </div>
                ))}
                {moodCalendar.map((item) => (
                  <div
                    key={item.day}
                    className={`aspect-square rounded-lg ${getMoodColor(
                      item.mood
                    )} flex items-center justify-center text-xs text-white font-medium cursor-pointer hover:scale-110 transition-transform shadow-sm`}
                  >
                    {item.day}
                  </div>
                ))}
              </div>

              {/* Legend */}
              <div className="flex items-center justify-center gap-6 mt-6 text-xs text-gray-600">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-400 rounded"></div>
                  <span>Good</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-yellow-400 rounded"></div>
                  <span>Neutral</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-400 rounded"></div>
                  <span>Challenging</span>
                </div>
              </div>
            </motion.div>

            {/* Word Cloud */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-lg border border-white/50 p-8"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl text-gray-800">Emotion Triggers</h2>
                  <p className="text-sm text-gray-500">Most used words</p>
                </div>
                <Cloud className="w-6 h-6 text-gray-600" />
              </div>

              {/* Word Cloud Display */}
              <div className="relative h-80 flex flex-wrap items-center justify-center gap-3 p-4">
                {wordCloudData.map((item, index) => (
                  <motion.span
                    key={index}
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.5 + index * 0.05 }}
                    style={{
                      fontSize: `${item.size}px`,
                      color: item.color,
                    }}
                    className="font-medium cursor-pointer hover:scale-110 transition-transform inline-block"
                  >
                    {item.word}
                  </motion.span>
                ))}
              </div>
            </motion.div>
          </div>

          {/* AI Insights Section */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-8 bg-gradient-to-r from-blue-500 to-green-500 rounded-3xl shadow-lg p-8 text-white"
          >
            <h2 className="text-2xl mb-4">AI-Powered Insights</h2>
            <div className="grid grid-cols-3 gap-6">
              <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-6">
                <h3 className="text-lg mb-2">Pattern Detected</h3>
                <p className="text-sm opacity-90">
                  Your mood tends to improve on weekends. Consider incorporating weekend activities into weekdays.
                </p>
              </div>
              <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-6">
                <h3 className="text-lg mb-2">Stress Triggers</h3>
                <p className="text-sm opacity-90">
                  Work-related words appear frequently during low mood periods. Try stress management techniques.
                </p>
              </div>
              <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-6">
                <h3 className="text-lg mb-2">Recommendation</h3>
                <p className="text-sm opacity-90">
                  Your consistent journaling is excellent! You're 2x more likely to maintain emotional balance.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
