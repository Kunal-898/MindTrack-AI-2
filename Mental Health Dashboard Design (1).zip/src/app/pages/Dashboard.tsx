import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Home, BookOpen, BarChart3, Settings, Brain, Sparkles, LogOut } from "lucide-react";
import { Textarea } from "../components/ui/textarea";
import { Button } from "../components/ui/button";
import MoodTracker from "../components/MoodTracker";
import WellnessTrend from "../components/WellnessTrend";
import EmotionCard from "../components/EmotionCard";
import { motion } from "motion/react";

export default function Dashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("home");
  const [journalText, setJournalText] = useState("");
  const [showEmotionCard, setShowEmotionCard] = useState(false);
  const [bgGradient, setBgGradient] = useState("from-blue-50 via-white to-green-50");

  // Mock AI emotion analysis
  const analyzeEmotion = () => {
    setShowEmotionCard(true);
  };

  // Change background gradient based on journal content (mock AI)
  useEffect(() => {
    const text = journalText.toLowerCase();
    if (text.includes("happy") || text.includes("joy") || text.includes("great")) {
      setBgGradient("from-yellow-50 via-white to-orange-50");
    } else if (text.includes("sad") || text.includes("anxious") || text.includes("stress")) {
      setBgGradient("from-gray-50 via-white to-blue-50");
    } else if (text.includes("calm") || text.includes("peace") || text.includes("relax")) {
      setBgGradient("from-green-50 via-white to-teal-50");
    } else {
      setBgGradient("from-blue-50 via-white to-green-50");
    }
  }, [journalText]);

  const mockEmotions = [
    { emotion: "Joy", percentage: 80, color: "#60A5FA" },
    { emotion: "Hope", percentage: 65, color: "#34D399" },
    { emotion: "Gratitude", percentage: 50, color: "#FBBF24" },
    { emotion: "Anxiety", percentage: 10, color: "#F87171" },
  ];

  const mockSuggestions = [
    "You're showing great emotional balance! Consider journaling daily to maintain this positive trend.",
    "Try a 5-minute breathing exercise to reduce the minor anxiety detected.",
    "Your gratitude levels are excellent. Keep acknowledging the positive aspects of your life.",
  ];

  const navigationItems = [
    { id: "home", icon: Home, label: "Home" },
    { id: "journal", icon: BookOpen, label: "Journal" },
    { id: "analytics", icon: BarChart3, label: "Analytics" },
    { id: "settings", icon: Settings, label: "Settings" },
  ];

  const handleNavigation = (id: string) => {
    setActiveTab(id);
    if (id === "analytics") {
      navigate("/analytics");
    } else if (id === "settings") {
      navigate("/settings");
    }
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br ${bgGradient} transition-all duration-1000`}>
      <div className="flex h-screen">
        {/* Left Sidebar */}
        <motion.div
          initial={{ x: -100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="w-20 bg-white/60 backdrop-blur-xl border-r border-white/50 flex flex-col items-center py-8 shadow-lg"
        >
          {/* Logo */}
          <div className="mb-12">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-green-500 rounded-2xl flex items-center justify-center shadow-lg">
              <Brain className="w-7 h-7 text-white" />
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 flex flex-col gap-6">
            {navigationItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavigation(item.id)}
                className={`p-4 rounded-2xl transition-all duration-300 group relative ${
                  activeTab === item.id
                    ? "bg-gradient-to-br from-blue-500 to-green-500 shadow-lg"
                    : "hover:bg-white/50"
                }`}
              >
                <item.icon
                  className={`w-6 h-6 ${
                    activeTab === item.id ? "text-white" : "text-gray-600 group-hover:text-gray-800"
                  }`}
                />
                {/* Tooltip */}
                <span className="absolute left-20 bg-gray-800 text-white text-xs px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                  {item.label}
                </span>
              </button>
            ))}
          </nav>

          {/* Logout */}
          <button
            onClick={() => navigate("/")}
            className="p-4 rounded-2xl hover:bg-red-50 transition-all group"
          >
            <LogOut className="w-6 h-6 text-gray-600 group-hover:text-red-500" />
          </button>
        </motion.div>

        {/* Main Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* Center Panel - Journaling */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex-1 p-8 overflow-y-auto"
          >
            {/* Header */}
            <div className="mb-8">
              <h1 className="text-3xl text-gray-800 mb-2">Welcome back! 👋</h1>
              <p className="text-gray-600">How are you feeling today?</p>
            </div>

            {/* Daily Journaling Section */}
            <div className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-lg border border-white/50 p-8 mb-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl text-gray-800">Daily Journaling</h2>
                  <p className="text-sm text-gray-500">Express your thoughts and feelings</p>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <Sparkles className="w-4 h-4" />
                  <span>AI-Powered Analysis</span>
                </div>
              </div>

              {/* Journal Input */}
              <Textarea
                placeholder="Start writing about your day... How do you feel? What's on your mind?"
                value={journalText}
                onChange={(e) => setJournalText(e.target.value)}
                className="min-h-[400px] bg-white/80 border-gray-200 rounded-2xl p-6 text-base resize-none focus:ring-2 focus:ring-blue-300 transition-all"
              />

              <div className="flex items-center justify-between mt-6">
                <div className="text-sm text-gray-500">
                  {journalText.length} characters • {journalText.split(/\s+/).filter(Boolean).length} words
                </div>
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    className="rounded-xl px-6 border-gray-200 hover:bg-white"
                  >
                    Save Draft
                  </Button>
                  <Button
                    onClick={analyzeEmotion}
                    disabled={journalText.length < 10}
                    className="bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600 text-white px-8 rounded-xl shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    Analyze Emotion
                  </Button>
                </div>
              </div>
            </div>

            {/* Wellness Trend Chart */}
            <WellnessTrend />

            {/* Quick Actions */}
            <div className="grid grid-cols-3 gap-4 mt-8">
              <div className="bg-gradient-to-br from-blue-400 to-blue-500 rounded-2xl p-6 text-white shadow-lg cursor-pointer hover:shadow-xl transition-all">
                <BookOpen className="w-8 h-8 mb-3" />
                <h4 className="text-sm mb-1">Past Entries</h4>
                <p className="text-xs opacity-90">View journal history</p>
              </div>
              <div className="bg-gradient-to-br from-green-400 to-green-500 rounded-2xl p-6 text-white shadow-lg cursor-pointer hover:shadow-xl transition-all">
                <BarChart3 className="w-8 h-8 mb-3" />
                <h4 className="text-sm mb-1">Insights</h4>
                <p className="text-xs opacity-90">See your progress</p>
              </div>
              <div className="bg-gradient-to-br from-purple-400 to-purple-500 rounded-2xl p-6 text-white shadow-lg cursor-pointer hover:shadow-xl transition-all">
                <Sparkles className="w-8 h-8 mb-3" />
                <h4 className="text-sm mb-1">AI Coach</h4>
                <p className="text-xs opacity-90">Get personalized tips</p>
              </div>
            </div>
          </motion.div>

          {/* Right Sidebar - Mood Tracker */}
          <motion.div
            initial={{ x: 100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="w-96 p-8 overflow-y-auto bg-gradient-to-b from-transparent to-white/20"
          >
            <MoodTracker />

            {/* Today's Quote */}
            <div className="mt-8 bg-white/70 backdrop-blur-xl rounded-3xl shadow-lg border border-white/50 p-6">
              <p className="text-xs text-gray-500 mb-2">Quote of the Day</p>
              <p className="text-sm text-gray-800 italic mb-3">
                "The greatest glory in living lies not in never falling, but in rising every time we fall."
              </p>
              <p className="text-xs text-gray-500">— Nelson Mandela</p>
            </div>

            {/* Mindfulness Reminder */}
            <div className="mt-6 bg-gradient-to-br from-blue-100 to-green-100 rounded-2xl p-5">
              <h4 className="text-sm text-gray-800 mb-2">Mindfulness Break</h4>
              <p className="text-xs text-gray-600 mb-4">
                Take a moment to breathe and center yourself.
              </p>
              <button className="w-full bg-white text-gray-700 py-2 rounded-xl text-sm hover:shadow-md transition-all">
                Start 5-min Exercise
              </button>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Emotion Analysis Modal */}
      <EmotionCard
        isOpen={showEmotionCard}
        onClose={() => setShowEmotionCard(false)}
        emotions={mockEmotions}
        suggestions={mockSuggestions}
      />
    </div>
  );
}
