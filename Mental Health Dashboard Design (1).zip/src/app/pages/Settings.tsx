import { useState } from "react";
import { useNavigate } from "react-router";
import { Home, BookOpen, BarChart3, Settings as SettingsIcon, Brain, LogOut, Bell, Lock, User, Palette, Shield } from "lucide-react";
import { Switch } from "../components/ui/switch";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { motion } from "motion/react";

export default function Settings() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("settings");
  const [notifications, setNotifications] = useState(true);
  const [dailyReminder, setDailyReminder] = useState(true);
  const [emailUpdates, setEmailUpdates] = useState(false);

  const navigationItems = [
    { id: "home", icon: Home, label: "Home" },
    { id: "journal", icon: BookOpen, label: "Journal" },
    { id: "analytics", icon: BarChart3, label: "Analytics" },
    { id: "settings", icon: SettingsIcon, label: "Settings" },
  ];

  const handleNavigation = (id: string) => {
    setActiveTab(id);
    if (id === "home" || id === "journal") {
      navigate("/dashboard");
    } else if (id === "analytics") {
      navigate("/analytics");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      <div className="flex h-screen">
        {/* Left Sidebar */}
        <div className="w-20 bg-white/60 backdrop-blur-xl border-r border-white/50 flex flex-col items-center py-8 shadow-lg">
          {/* Logo */}
          <div className="mb-12">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-green-500 rounded-2xl flex items-center justify-center shadow-lg">
              <Brain className="w-7 h-7 text-white" />
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 flex flex-col gap-6">
            {navigationItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavigation(item.id)}
                className={`p-4 rounded-2xl transition-all duration-300 group relative ${
                  activeTab === item.id
                    ? "bg-gradient-to-br from-blue-500 to-green-500 shadow-lg"
                    : "hover:bg-white/50"
                }`}
              >
                <item.icon
                  className={`w-6 h-6 ${
                    activeTab === item.id ? "text-white" : "text-gray-600 group-hover:text-gray-800"
                  }`}
                />
                <span className="absolute left-20 bg-gray-800 text-white text-xs px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                  {item.label}
                </span>
              </button>
            ))}
          </nav>

          {/* Logout */}
          <button
            onClick={() => navigate("/")}
            className="p-4 rounded-2xl hover:bg-red-50 transition-all group"
          >
            <LogOut className="w-6 h-6 text-gray-600 group-hover:text-red-500" />
          </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8 overflow-y-auto">
          {/* Header */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <h1 className="text-3xl text-gray-800 mb-2">Settings</h1>
            <p className="text-gray-600">Manage your account and preferences</p>
          </motion.div>

          <div className="max-w-4xl">
            {/* Profile Section */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-lg border border-white/50 p-8 mb-6"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="p-3 bg-blue-100 rounded-2xl">
                  <User className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h2 className="text-xl text-gray-800">Profile Information</h2>
                  <p className="text-sm text-gray-500">Update your personal details</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">Full Name</label>
                  <Input
                    type="text"
                    defaultValue="John Doe"
                    className="bg-white/80 border-gray-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-700 mb-2">Email Address</label>
                  <Input
                    type="email"
                    defaultValue="john.doe@example.com"
                    className="bg-white/80 border-gray-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-700 mb-2">Time Zone</label>
                  <Input
                    type="text"
                    defaultValue="UTC-5 (EST)"
                    className="bg-white/80 border-gray-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-700 mb-2">Language</label>
                  <Input
                    type="text"
                    defaultValue="English (US)"
                    className="bg-white/80 border-gray-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="flex justify-end mt-6">
                <Button className="bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600 text-white px-6 rounded-xl">
                  Save Changes
                </Button>
              </div>
            </motion.div>

            {/* Notifications */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-lg border border-white/50 p-8 mb-6"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="p-3 bg-green-100 rounded-2xl">
                  <Bell className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h2 className="text-xl text-gray-800">Notifications</h2>
                  <p className="text-sm text-gray-500">Manage your notification preferences</p>
                </div>
              </div>

              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm text-gray-800">Push Notifications</h4>
                    <p className="text-xs text-gray-500">Receive notifications on your device</p>
                  </div>
                  <Switch checked={notifications} onCheckedChange={setNotifications} />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm text-gray-800">Daily Journal Reminder</h4>
                    <p className="text-xs text-gray-500">Get reminded to write in your journal</p>
                  </div>
                  <Switch checked={dailyReminder} onCheckedChange={setDailyReminder} />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm text-gray-800">Email Updates</h4>
                    <p className="text-xs text-gray-500">Receive weekly insights via email</p>
                  </div>
                  <Switch checked={emailUpdates} onCheckedChange={setEmailUpdates} />
                </div>
              </div>
            </motion.div>

            {/* Privacy & Security */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-lg border border-white/50 p-8 mb-6"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="p-3 bg-purple-100 rounded-2xl">
                  <Shield className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h2 className="text-xl text-gray-800">Privacy & Security</h2>
                  <p className="text-sm text-gray-500">Control your data and security settings</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-blue-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <Lock className="w-5 h-5 text-blue-600" />
                    <div>
                      <h4 className="text-sm text-gray-800">Change Password</h4>
                      <p className="text-xs text-gray-500">Update your account password</p>
                    </div>
                  </div>
                  <Button variant="outline" className="rounded-xl">Change</Button>
                </div>

                <div className="flex items-center justify-between p-4 bg-green-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <Shield className="w-5 h-5 text-green-600" />
                    <div>
                      <h4 className="text-sm text-gray-800">Two-Factor Authentication</h4>
                      <p className="text-xs text-gray-500">Add an extra layer of security</p>
                    </div>
                  </div>
                  <Button variant="outline" className="rounded-xl">Enable</Button>
                </div>

                <div className="flex items-center justify-between p-4 bg-orange-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <User className="w-5 h-5 text-orange-600" />
                    <div>
                      <h4 className="text-sm text-gray-800">Download Your Data</h4>
                      <p className="text-xs text-gray-500">Export all your journal entries</p>
                    </div>
                  </div>
                  <Button variant="outline" className="rounded-xl">Download</Button>
                </div>
              </div>
            </motion.div>

            {/* Appearance */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-lg border border-white/50 p-8 mb-6"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="p-3 bg-pink-100 rounded-2xl">
                  <Palette className="w-6 h-6 text-pink-600" />
                </div>
                <div>
                  <h2 className="text-xl text-gray-800">Appearance</h2>
                  <p className="text-sm text-gray-500">Customize how MINDTRACK looks</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 border-2 border-blue-500 rounded-xl cursor-pointer bg-white">
                  <div className="w-full h-20 bg-gradient-to-br from-blue-100 to-green-100 rounded-lg mb-3"></div>
                  <p className="text-sm text-gray-800 text-center">Default</p>
                </div>
                <div className="p-4 border-2 border-transparent hover:border-gray-300 rounded-xl cursor-pointer bg-white">
                  <div className="w-full h-20 bg-gradient-to-br from-purple-100 to-pink-100 rounded-lg mb-3"></div>
                  <p className="text-sm text-gray-800 text-center">Sunset</p>
                </div>
                <div className="p-4 border-2 border-transparent hover:border-gray-300 rounded-xl cursor-pointer bg-white">
                  <div className="w-full h-20 bg-gradient-to-br from-gray-800 to-gray-600 rounded-lg mb-3"></div>
                  <p className="text-sm text-gray-800 text-center">Dark</p>
                </div>
              </div>
            </motion.div>

            {/* Danger Zone */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="bg-red-50/70 backdrop-blur-xl rounded-3xl shadow-lg border border-red-200/50 p-8"
            >
              <h2 className="text-xl text-red-700 mb-4">Danger Zone</h2>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-white rounded-xl">
                  <div>
                    <h4 className="text-sm text-gray-800">Delete All Journal Entries</h4>
                    <p className="text-xs text-gray-500">This action cannot be undone</p>
                  </div>
                  <Button variant="outline" className="rounded-xl text-red-600 border-red-300 hover:bg-red-50">
                    Delete
                  </Button>
                </div>
                <div className="flex items-center justify-between p-4 bg-white rounded-xl">
                  <div>
                    <h4 className="text-sm text-gray-800">Delete Account</h4>
                    <p className="text-xs text-gray-500">Permanently delete your account and all data</p>
                  </div>
                  <Button variant="outline" className="rounded-xl text-red-600 border-red-300 hover:bg-red-50">
                    Delete Account
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
